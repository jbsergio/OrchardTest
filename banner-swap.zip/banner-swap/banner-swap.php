<?php
/*
Plugin Name:  Banner Swap
Description:  A short little description of the plugin. It will be displayed on the Plugins page in WordPress admin area.
Version:      1.0
Author:       Neil
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;


function swap_banner($content) {
 
 $plugin_dir =  '/wp-content/plugins/banner-swap';
 $menu_name = 'primary';
 $locations = get_nav_menu_locations();
 $menu = wp_get_nav_menu_object( $locations[$menu_name] );
 $menuitems = wp_get_nav_menu_items( $menu->term_id, array( 'order' => 'DESC' ) );
 $parentMenu = getParentMenuItems($menuitems);
 $pageId = get_the_ID();
 $menuID = getOriginalPageID($pageId);
 $img='';

 foreach ($menuitems as $item){
    if(($item->object_id == $pageId && $item->menu_item_parent == $parentMenu[0]) || ($item->ID == $parentMenu[0] && $pageId == $item->object_id)){
        $img = '<div class="widefat"><img src="'.$plugin_dir.'/images/image1.jpg" /></div>';
    } elseif (($item->object_id == $pageId && $item->menu_item_parent == $parentMenu[1]) || ($item->ID == $parentMenu[1]  && $pageId == $item->object_id)){
        $img = '<div class="widefat"><img src="'.$plugin_dir.'/images/image2.jpg" /></div>';
    }
 }


 // Return the content
 return $content .= $img; 
  
 }
 add_filter('the_content', 'swap_banner'); 


function getOriginalPageID ($pageId){
    global $wpdb;
    $query = $wpdb->prepare("SELECT post_id from {$wpdb->prefix}postmeta where meta_value = %d", $pageId);
    $results = $wpdb->get_results($query);
    return (count($results) > 0) ?$results[0]->post_id : false;
}
function getParentMenuItems(array $menuitems){
    $parentMenu = [];
    foreach ($menuitems as $item){
        if($item->menu_item_parent == 0){
            array_push( $parentMenu, $item->ID);
        }
     }

     return $parentMenu;
}

