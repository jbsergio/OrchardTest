<?php
/*
Plugin Name:  Product of The Day Generator
Description:  Generate a product of the day widget
Version:      1.0
Author:       Neil
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;
global $wpdb;
//create DB table
register_activation_hook ( __FILE__, 'on_activate' );

function on_activate() {
    
    $table_name = $wpdb->prefix."potd";
    if ($wpdb->get_var('SHOW TABLES LIKE '.$table_name) != $table_name) {
        $sql = 'CREATE TABLE '.$table_name.'(
            ID INTEGER NOT NULL,
            image_url VARCHAR(3),
            potd BOOL DEFAULT 0,
            PRIMARY KEY  (id))';

        require_once(ABSPATH.'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}

// create menu section
add_action( 'admin_menu', 'my_plugin_menu' );

function my_plugin_menu() {
	add_options_page( 'Product of the Day', 'Product of the Day', 'manage_options', 'product-of-the-day', 'my_plugin_options' );
}

function my_plugin_options() {
	if ( !current_user_can( 'manage_options' ) )  {
		wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
	}
	potd_dashboard();
}


function potd_dashboard(){

    echo '
        <div>
            <h1>Product of the Day</h1>
        </div>
        <div><button onclick="jQuery(\'#form-upload\').show()">Upload Image</button></div>
        <div id="form-upload" style="display:none;">';
        upload();
        echo '</div>
        <div>';
        if(!(is_null(get_images()))){
            echo '<table class="wp-list-table widefat fixed striped table-view-list media">
                <thead>
                    <tr>
                        <td>Image</td>
                        <td>Product of the day?</td>
                </thead>
                <tbody>';
                foreach (get_images() as $image){
                   echo " <tr class='title column-title has-row-actions column-primary'>
                        <td><span><img src='{$image->guid}' height=60 /></span></td>
                        <td><input type='checkbox' name='potd' /></td>
                    <tr>";
                }
                echo '</tbody>
            </table>';
        } else {
            echo 'No Uploaded Image.';
        }
        echo '</div>';
        
}

function get_images(){
    global $wpdb;
    $images = $wpdb->prepare("SELECT * from {$wpdb->prefix}posts WHERE post_type = 'attachment' AND post_mime_type LIKE 'image%' ORDER by ID DESC;");
    return $wpdb->get_results($images);
}

function upload(){
	echo '<form action="/wp-content/plugins/product-of-the-day/upload.php" method="post" enctype="multipart/form-data">
	Upload Image: <input type="file" name="profile_picture" />
	<input type="submit" name="submit" value="Submit" />
	</form>';
}