<form action="' . get_stylesheet_directory_uri() . '/process_upload.php" method="post" enctype="multipart/form-data">
	Upload Image: <input type="file" name="profile_picture" />
	<input type="submit" name="submit" value="Submit" />
	</form>